__version__ = "1.18.0"  # x-release-please-version

# Load .env vars from file before everything else
# usecwd=True walks up from CWD (user's project) instead of from the
# package source file location, which matters for editable installs.
from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv(usecwd=True))

from .logger import setup_logging  # noqa: E402

setup_logging()

# TYPE_CHECKING imports provide full IDE support (autocomplete, type hints)
# while __getattr__ enables lazy loading at runtime for fast CLI startup
from typing import TYPE_CHECKING  # noqa: E402

if TYPE_CHECKING:
    from .client import remote
    from .endpoint import Endpoint, EndpointJob
    from .core.resources import (
        CPU_DATACENTERS,
        CpuInstanceType,
        CpuLiveLoadBalancer,
        CpuLiveServerless,
        CpuLoadBalancerSlsResource,
        CpuServerlessEndpoint,
        CudaVersion,
        DataCenter,
        GpuGroup,
        GpuType,
        LiveLoadBalancer,
        LiveServerless,
        LoadBalancerSlsResource,
        NetworkVolume,
        PodTemplate,
        ResourceManager,
        ServerlessEndpoint,
        ServerlessScalerType,
        ServerlessType,
        FlashApp,
    )
    from .core.resources.constants import (
        DEFAULT_WORKERS_MAX,
        DEFAULT_WORKERS_MIN,
    )


_DEPRECATED_RESOURCE_CLASSES = frozenset(
    {
        "CpuLiveLoadBalancer",
        "CpuLiveServerless",
        "CpuLoadBalancerSlsResource",
        "CpuServerlessEndpoint",
        "LiveLoadBalancer",
        "LiveServerless",
        "LoadBalancerSlsResource",
        "ServerlessEndpoint",
    }
)

_RESOURCE_NAMES = frozenset(
    {
        "CPU_DATACENTERS",
        "CpuInstanceType",
        "CpuLiveLoadBalancer",
        "CpuLiveServerless",
        "CpuLoadBalancerSlsResource",
        "CpuServerlessEndpoint",
        "CudaVersion",
        "DataCenter",
        "GpuGroup",
        "GpuType",
        "LiveLoadBalancer",
        "LiveServerless",
        "LoadBalancerSlsResource",
        "NetworkVolume",
        "PodTemplate",
        "ResourceManager",
        "ServerlessEndpoint",
        "ServerlessScalerType",
        "ServerlessType",
        "FlashApp",
    }
)


def __getattr__(name):
    """Lazily import core modules only when accessed."""
    import warnings

    if name == "Endpoint":
        from .endpoint import Endpoint

        return Endpoint
    elif name == "EndpointJob":
        from .endpoint import EndpointJob

        return EndpointJob
    elif name == "remote":
        from .client import remote

        warnings.warn(
            "runpod_flash.remote is deprecated. Use runpod_flash.Endpoint instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return remote
    elif name in _RESOURCE_NAMES:
        from .core.resources import (
            CPU_DATACENTERS,
            CpuInstanceType,
            CpuLiveLoadBalancer,
            CpuLiveServerless,
            CpuLoadBalancerSlsResource,
            CpuServerlessEndpoint,
            CudaVersion,
            DataCenter,
            GpuGroup,
            GpuType,
            LiveLoadBalancer,
            LiveServerless,
            LoadBalancerSlsResource,
            NetworkVolume,
            PodTemplate,
            ResourceManager,
            ServerlessEndpoint,
            ServerlessScalerType,
            ServerlessType,
            FlashApp,
        )

        attrs = {
            "CPU_DATACENTERS": CPU_DATACENTERS,
            "CpuInstanceType": CpuInstanceType,
            "CpuLiveLoadBalancer": CpuLiveLoadBalancer,
            "CpuLiveServerless": CpuLiveServerless,
            "CpuLoadBalancerSlsResource": CpuLoadBalancerSlsResource,
            "CpuServerlessEndpoint": CpuServerlessEndpoint,
            "CudaVersion": CudaVersion,
            "DataCenter": DataCenter,
            "GpuGroup": GpuGroup,
            "GpuType": GpuType,
            "LiveLoadBalancer": LiveLoadBalancer,
            "LiveServerless": LiveServerless,
            "LoadBalancerSlsResource": LoadBalancerSlsResource,
            "NetworkVolume": NetworkVolume,
            "PodTemplate": PodTemplate,
            "ResourceManager": ResourceManager,
            "ServerlessEndpoint": ServerlessEndpoint,
            "ServerlessScalerType": ServerlessScalerType,
            "ServerlessType": ServerlessType,
            "FlashApp": FlashApp,
        }

        if name in _DEPRECATED_RESOURCE_CLASSES:
            warnings.warn(
                f"runpod_flash.{name} is deprecated. Use runpod_flash.Endpoint instead.",
                DeprecationWarning,
                stacklevel=2,
            )

        return attrs[name]
    elif name in ("DEFAULT_WORKERS_MIN", "DEFAULT_WORKERS_MAX"):
        from .core.resources.constants import (
            DEFAULT_WORKERS_MAX,
            DEFAULT_WORKERS_MIN,
        )

        attrs = {
            "DEFAULT_WORKERS_MIN": DEFAULT_WORKERS_MIN,
            "DEFAULT_WORKERS_MAX": DEFAULT_WORKERS_MAX,
        }
        return attrs[name]
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "Endpoint",
    "EndpointJob",
    "remote",
    "CPU_DATACENTERS",
    "CpuInstanceType",
    "CpuLiveLoadBalancer",
    "CpuLiveServerless",
    "CpuLoadBalancerSlsResource",
    "CpuServerlessEndpoint",
    "CudaVersion",
    "DataCenter",
    "GpuGroup",
    "GpuType",
    "LiveLoadBalancer",
    "LiveServerless",
    "LoadBalancerSlsResource",
    "NetworkVolume",
    "PodTemplate",
    "ResourceManager",
    "ServerlessEndpoint",
    "ServerlessScalerType",
    "ServerlessType",
    "FlashApp",
    "DEFAULT_WORKERS_MIN",
    "DEFAULT_WORKERS_MAX",
]
